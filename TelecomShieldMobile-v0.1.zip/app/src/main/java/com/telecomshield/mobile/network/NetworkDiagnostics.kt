package com.telecomshield.mobile.network

import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.NetworkCapabilities
import android.os.Build
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.NetworkInterface

object NetworkDiagnostics {

    data class Result(
        val transport: String,
        val ipv4: String,
        val ipv6: String,
        val dns: String,
        val interfaceName: String
    )

    suspend fun scan(): Result {
        var transport = "Unknown"
        var ipv4 = "Not detected"
        var ipv6 = "Not detected"
        var dns = "Not detected"
        var iface = "Unknown"

        val interfaces = NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
        val active = interfaces.firstOrNull { it.isUp && !it.isLoopback }

        active?.let {
            iface = it.name
            val addresses = it.inetAddresses.toList()
            ipv4 = addresses.filterIsInstance<Inet4Address>()
                .firstOrNull()?.hostAddress ?: ipv4
            ipv6 = addresses.filterIsInstance<Inet6Address>()
                .firstOrNull()?.hostAddress ?: ipv6
        }

        return Result(
            transport = transport,
            ipv4 = ipv4,
            ipv6 = ipv6,
            dns = dns,
            interfaceName = iface
        )
    }
}
