package com.telecomshield.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.telecomshield.mobile.network.NetworkDiagnostics
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TelecomShieldTheme {
                TelecomShieldApp()
            }
        }
    }
}

@Composable
private fun TelecomShieldTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF6EA8FE),
            secondary = Color(0xFF7EE2B8),
            background = Color(0xFF080C16),
            surface = Color(0xFF111827)
        ),
        content = content
    )
}

@Composable
private fun TelecomShieldApp() {
    var screen by remember { mutableStateOf("dashboard") }
    val scope = rememberCoroutineScope()
    var running by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<NetworkDiagnostics.Result?>(null) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = screen == "dashboard",
                    onClick = { screen = "dashboard" },
                    icon = { Icon(Icons.Default.Dashboard, null) },
                    label = { Text("Dashboard") }
                )
                NavigationBarItem(
                    selected = screen == "findings",
                    onClick = { screen = "findings" },
                    icon = { Icon(Icons.Default.Security, null) },
                    label = { Text("Findings") }
                )
                NavigationBarItem(
                    selected = screen == "reports",
                    onClick = { screen = "reports" },
                    icon = { Icon(Icons.Default.Description, null) },
                    label = { Text("Reports") }
                )
            }
        }
    ) { padding ->
        when (screen) {
            "dashboard" -> Dashboard(
                modifier = Modifier.padding(padding),
                running = running,
                result = result,
                onScan = {
                    running = true
                    scope.launch {
                        result = NetworkDiagnostics.scan()
                        running = false
                    }
                }
            )
            "findings" -> Findings(modifier = Modifier.padding(padding))
            "reports" -> Reports(modifier = Modifier.padding(padding))
        }
    }
}

@Composable
private fun Dashboard(
    modifier: Modifier,
    running: Boolean,
    result: NetworkDiagnostics.Result?,
    onScan: () -> Unit
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF080C16))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                "TelecomShield",
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Mobile Telecom Security Auditor",
                color = Color.LightGray
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF111827))
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text("NETWORK STATUS", color = Color.LightGray, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        result?.transport ?: "Ready for discovery",
                        fontSize = 21.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(14.dp))
                    Button(
                        onClick = onScan,
                        enabled = !running,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.NetworkCheck, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (running) "Scanning..." else "DISCOVER NETWORK")
                    }
                }
            }
        }

        item { MetricCard("IPv4", result?.ipv4 ?: "—") }
        item { MetricCard("IPv6", result?.ipv6 ?: "—") }
        item { MetricCard("DNS", result?.dns ?: "—") }
        item { MetricCard("Interface", result?.interfaceName ?: "—") }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text("AUDIT PIPELINE", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    Text("DISCOVER  →  ANALYZE  →  EVIDENCE  →  FINDING  →  RETEST")
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "v0.1 currently provides local network discovery. Active authorized validation modules can be added on this foundation.",
                        color = Color.LightGray,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(18.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(title, color = Color.LightGray)
            Text(value, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun Findings(modifier: Modifier) {
    val findings = listOf(
        "No confirmed findings yet",
        "Run Network Discovery first",
        "Active validation engine: planned for next module"
    )
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF080C16))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Findings", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Evidence-backed security findings", color = Color.LightGray)
        }
        items(findings) { item ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(item, Modifier.padding(18.dp))
            }
        }
    }
}

@Composable
private fun Reports(modifier: Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF080C16))
            .padding(18.dp)
    ) {
        Text("Reports", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Report generation module is prepared for the next build stage.",
            color = Color.LightGray
        )
    }
}
