TelecomShield Mobile - GitHub Actions

Copy this folder's .github/workflows/build-apk.yml into the root of your Android project.

Then:
1. Commit/push it to the main branch.
2. Open GitHub -> Actions.
3. Select "Build Android APK".
4. Tap "Run workflow" if you want to build manually.
5. Open the completed run.
6. Download the "TelecomShieldMobile-debug" artifact.

This workflow builds a DEBUG APK for authorized testing. It does not implement
generic internet/billing bypass functionality.
